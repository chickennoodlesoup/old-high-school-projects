import java.util.Scanner;
import java.util.ArrayList;
public class HoningYourSkills {
    public static void main(String[] args) {
        // ArrayList and String Class
        // 1. 
        // make scanner object
        Scanner scan = new Scanner(System.in);
        // print this before asking for output
        System.out.println("Enter a number to make 6 digits long.");
        // ask for input
        String number = scan.nextLine();
        // get the length of the digit
        int numLength = number.length();
        // less than 6 digits
        if (numLength < 6){
            // find how many extra zero are needed
            numLength = 6 - numLength;
            // add required zeros
            for(;numLength>0;numLength--){
                number = "0"+number;
            }
            System.out.println(number);
        }
        // more than or equal to 6 digits
        else{
            System.out.println("Your number is already longer than 6 digits.");
        }
        
        // 2.
        // a.
        // make array list
        ArrayList<Integer> randomNumbers = new ArrayList<Integer>();
        // add 10 random numbers between 1 and 100 to it
        for(int wordLength=0;wordLength<10;wordLength++){
            randomNumbers.add((int)(Math.random()*100)+1);
        }
        // b. 
        // make array list
        ArrayList<Integer> copiedList = new ArrayList<Integer>();
        // for every item in randomNumbers add it to copiedList
        for(int n:randomNumbers){
            copiedList.add(n);
        }
        // c.
        // set last index in randomNumbers equal to -7
        randomNumbers.set(randomNumbers.size()-1,-7);
        // d.
        // print results
        System.out.println(randomNumbers);
        System.out.println(copiedList);
        // 3.
        // a.
        // make array list
        ArrayList<Integer> oneToHundred = new ArrayList<Integer>();
        // add numbers 1-100 to the list
        for(int wordLength=1;wordLength<101;wordLength++){
            oneToHundred.add(wordLength);
        }
        System.out.println(oneToHundred);
        // b.
        // make array list
        ArrayList<Integer> reversedList = new ArrayList<Integer>();
        // for every item in oneToHundred, add it to the front of the reversedList to get an reversed list
        for(int wordLength:oneToHundred){
            reversedList.add(0,wordLength);
        }
        System.out.println(reversedList);
        // c.
        // remove every even number
        // list shrinks by 1 each loop, so only add 1 to counter after each loop
        for(int counter=0;counter<50;counter++){
            reversedList.remove(counter);
        }
        System.out.println(reversedList);
        
        // 4.
        // get user input
        System.out.println("Enter a word to be scrambled.");
        String userWord = scan.nextLine();
        // use word scrambler method: line 125
        System.out.println(wordScrambler(userWord));
        
        // 5.
        String sentence="This is a long sentence that you will search through and find some values of using the string class";
        // remove spaces from the sentence and make all the letters lowercase
        sentence = sentence.replaceAll("\\s+","");
        sentence = sentence.toLowerCase();
        // some variables
        String vowels="aeiou";    
        int len=sentence.length();
        int numVowels=0;  
        int lastTh=-1;  
        int numTh=0;
        // check every letter in sentence
        // if the letter is in vowels (index >-1) then increase numVowels by one    
        for(int counter=0;counter<len;counter++){
            if(vowels.indexOf(sentence.substring(counter,counter+1))>=0){
                numVowels++;
            }                        
        }
        // go through the sentence
        for(int counter=0;counter<len;counter++){
            // set lastTh to the index of the next "th" in the sentence
            // if there are no more "th" with an index number greater than lastTh in the sentence, lastTh will equal -1 
            lastTh=sentence.indexOf("th",lastTh+1);
            if(lastTh>=0){  
                // add one to numTh  
                numTh++;
                // make the counter equal to lastTh so it can find the next "th" string in the next loop
                counter=lastTh;
            }
            // there are no more "th" strings in sentence with an index, so end the loop
            else{
                break;
            }    
        }
        // print results
        System.out.println("Vowels: "+numVowels);
        // every letter that is not a vowel is a consonant because all the spaces are removed
        System.out.println("Consonants: "+(len-numVowels));
        System.out.println("Number of \"th\": "+numTh);
    }
    // 4.
    // method that returns string, takes in a string
    public static String wordScrambler(String userWord){
        // make array list
        ArrayList<String> charList = new ArrayList<String>();
        // find the length of the word
        int wordLength = userWord.length();
        // make extra index to prevent IndexOutOfBounds error
        userWord ="."+userWord;
        int random;
        for(;wordLength>0;wordLength--){
            // get a random position in the arrayList
            random = (int)(Math.random()*charList.size());
            // for every letter in userWord add it to the random position in charList
            charList.add(random,userWord.substring(wordLength,wordLength+1));
        }
        String newWord ="";
        // change list to string
        // for every item (a character) in the list add it to newWord
        for(String c:charList){
            newWord+=c;
        }
        // return the scrambled word
        return(newWord);
        
    }
}




        
    
    
    

