import java.util.ArrayList;
public class School {
    private final ArrayList<Person> ROSTER = new ArrayList<>();
    
    // method that adds a person to roster array
    public void addPerson(Person person){
        ROSTER.add(person);
    }
    
    // method that displays all the names of the people in the roster
    public String displayNames(){
        String names="";
        // goes through the array
        // gets each person's full name and adds it to names
        for(int i=0;i<ROSTER.size();++i){
            names+=ROSTER.get(i).getName()+"\n";
        }
        // return the string  
        return(names);
    }
    
    public Student getFirstStudent(){
        // goes through the array
        // when it finds a person that is an instance of Student,
        // return it as a Student
        for(int i=0;i<ROSTER.size();++i){
            if(ROSTER.get(i) instanceof Student){
                return((Student)ROSTER.get(i));
            }
        }
        // if there are no students return this
        return(null);
    }
    public Teacher getFirstTeacher(){
        // goes through the array
        // when it finds a person that is an instance of Teacher,
        // return it as a Teacher
        for(int i=0;i<ROSTER.size();++i){
            if(ROSTER.get(i) instanceof Teacher){
                return((Teacher)ROSTER.get(i));
            }
        }
        // if there are no teachers return this
        return(null);
    }
    public ExchangeStudent getFirstExchangeStudent(){
        // goes through the array
        // when it finds a person that is an instance of ExchangeStudent,
        // return it as a ExchangeStudent
        for(int i=0;i<ROSTER.size();++i){
            if(ROSTER.get(i) instanceof ExchangeStudent){
                return((ExchangeStudent)ROSTER.get(i));
            }
        }
        // if there are no exchange students return this
        return(null);
    }
    
    public ArrayList<Teacher> getAllTeachers(){
        ArrayList<Teacher> temp=new ArrayList<>();
        // goes through the array
        // whenever it finds a person that is an instance of Teacher,
        // add it to the array as an Teacher
        for(int i=0;i<ROSTER.size();++i){
            if(ROSTER.get(i) instanceof Teacher){
                temp.add((Teacher)ROSTER.get(i));
            }
        }
        // return the array 
        return(temp);
    }
    public ArrayList<Student> getAllStudents(){
        ArrayList<Student> temp=new ArrayList<>();
        // goes through the array
        // whenever it finds a person that is an instance of Student,
        // add it to the array as an Student        
        for(int i=0;i<ROSTER.size();++i){
            if(ROSTER.get(i) instanceof Student){
                temp.add((Student)ROSTER.get(i));
            }
        }
       // return the array 
       return(temp);
    }
    public ArrayList<ExchangeStudent> getAllExchangeStudents(){       
        ArrayList<ExchangeStudent> temp=new ArrayList<>();
        // goes through the array
        // whenever it finds a person that is an instance of ExchangeStudent,
        // add it to the array as an ExchangeStudent          
        for(int i=0;i<ROSTER.size();++i){
            if(ROSTER.get(i) instanceof ExchangeStudent){
                temp.add((ExchangeStudent)ROSTER.get(i));
            }
        }
       // return the array 
       return(temp);
    }
    
}

