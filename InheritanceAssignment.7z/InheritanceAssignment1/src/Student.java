import java.util.ArrayList;
public class Student extends Person {
    // variables
    private static int currentStudentId = 0;
    
    // constructor takes in two Strings
    public Student(String firstName, String lastName) {
        // call super class with those two Strings as arguments
        super(firstName, lastName);
        // set the Id and add one to the currentStudentId 
        this.personId = currentStudentId;
        ++currentStudentId;
    }
    
    // method that takes a course and adds it to the ArrayList COURSES
    @Override
    public void addCourse(Course course) {
        this.COURSES.add(course);
    }

    // method that takes a course and removes it to the ArrayList COURSES
    // does nothing if the course is not in the ArrayList
    @Override
    public void delCourse(Course course) {
        this.COURSES.remove(course);
    }

    // method that prints all the COURSES in the COURSES ArrayList
    @Override
    public ArrayList<Course> getCourses(){
        return(COURSES);
    }

    // method that returns the student's Id
    @Override
    public int getId() {
        return (this.personId);
    }
    
    // this gets called in toString() when a student is printed
    // (overrides Person's speak() method)
    @Override
    protected String speak(){
        return("I am a student.");
    }
}
