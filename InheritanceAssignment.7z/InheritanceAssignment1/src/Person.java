import java.util.ArrayList;
public abstract class Person {
    protected int personId;
    protected final ArrayList<Course> COURSES=new ArrayList<>();
    private final String FIRSTNAME,LASTNAME;
    
    // constructor takes in two Strings
    public Person(String firstName, String lastName){
        // sets those two Strings to FIRSTNAME and LASTNAME
        FIRSTNAME=firstName;
        LASTNAME=lastName;
    }
    

    // toString runs when Person is printed 
    // when it runs call the Person's speak() method       
    @Override
    public String toString(){
        return(this.speak());
    }
    
    // this gets called in toString() when a Person is printed
    protected abstract String speak(); 
    
    // methods to override
    protected abstract void addCourse(Course course); 
    protected abstract void delCourse(Course course);
    protected abstract ArrayList<Course> getCourses();
    protected abstract int getId();
    
    // print full name of Person
    public String getName(){
        return(this.FIRSTNAME+" "+this.LASTNAME);
    }
    
    
    
   
    
}
