public class Course {
    private final String COURSENAME;
     
    // constructor that takes in a String
    public Course(String courseName){
        // set this.COURSENAME to the String
        this.COURSENAME=courseName;
    }
    
    // when the course is printed, print it's COURSENAME instead
    @Override
    public String toString(){
        return(this.COURSENAME);
    }
}
