public class ExchangeStudent extends Student{
    // variables
    private final String returnDate;   
    
    // constuctor that takes in 3 strings
    public ExchangeStudent(String firstName,String lastName,String returnDate){
        // put the first two strings into the Person constructor 
        // and set returnDate to the last string
        super(firstName,lastName);
        this.returnDate=returnDate;
    }
    
    // return returnDate
    public String getReturnDate(){
        return(this.returnDate);
    }
    
    // this gets called in toString() when an exchange student is printed
    // (overrides Student's speak() method
    @Override
    protected String speak(){
        return("I am an exchange student.");
    }
    
    
}
