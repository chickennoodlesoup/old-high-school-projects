public class InheritanceAssignment1 {
    public static void main(String[] args) {
        
        // TESTING: 
        
        // Create 
        Course c= new Course("Math");
        Course c2= new Course("English");
        
        Teacher t= new Teacher("Ken","M");
        Teacher t2= new Teacher("A","B");
        
        Student s= new Student("Joe","S");
        
        ExchangeStudent es=new ExchangeStudent("fname","lname","Jan 7 2018");
  
        School school= new School();
        
        // COURSES
        System.out.println("Courses:");
        System.out.println(c);
        System.out.println(c2);
        
        // TEACHER
        System.out.println("\nTeacher 1:");
        System.out.println(t);
        System.out.println(t.getName());
        System.out.println(t.getId());
        t.addCourse(c);
        t.delCourse(c);
        System.out.println(t.getCourses());
        
        System.out.println("\nTeacher 2:");
        System.out.println(t2);
        System.out.println(t2.getName());
        System.out.println(t2.getId());
        t2.addCourse(c);
        t2.addCourse(c2);
        System.out.println(t2.getCourses());
        
        // STUDENT
        System.out.println("\nStudent:");
        System.out.println(s);
        System.out.println(s.getName());
        System.out.println(s.getId());
        s.addCourse(c);
        s.delCourse(c2);
        System.out.println(s.getCourses());
        
        // EXCHANGE STUDENT
        System.out.println("\nExchange Student:");
        System.out.println(es);
        System.out.println(es.getName());
        System.out.println(es.getId());
        es.addCourse(c);
        es.addCourse(c);
        System.out.println(es.getCourses());
        System.out.println(es.getReturnDate());        
        
        // SCHOOL        
        System.out.println("\nSchool:");
        // these will return null bec there are no people in the school
        System.out.println(school.getFirstStudent());
        System.out.println(school.getFirstTeacher());
        System.out.println(school.getFirstExchangeStudent());
        
        school.addPerson(t);
        school.addPerson(t2);
        school.addPerson(s);
        school.addPerson(es);
        System.out.println("\n"+school.displayNames());
        
        System.out.println(school.getFirstStudent());
        System.out.println(school.getFirstTeacher());
        System.out.println(school.getFirstExchangeStudent()+"\n");
        
        System.out.println(school.getAllStudents());
        System.out.println(school.getAllTeachers());
        System.out.println(school.getAllExchangeStudents());  

        // Test some methods on the returned objects          
        System.out.println("\n"+school.getFirstStudent().getId());
        System.out.println(school.getFirstTeacher().getCourses());
        school.getFirstExchangeStudent().delCourse(c2);
        
        System.out.println("\n"+school.getAllStudents().get(0).getName());
        school.getAllTeachers().get(1).addCourse(c);
        System.out.println(school.getAllExchangeStudents().get(0).getReturnDate());
    }
               
    
}
