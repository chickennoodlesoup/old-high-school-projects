import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
import java.util.Random;
public class SearchAlgorithms { 
    public static void main(String[] args) {
        // make scanner object
        Scanner scan = new Scanner(System.in);
        int lenOfList;
        // print this before asking for output
        
        // keep asking user for length of list until they enter a non-negative integer
        do{
            System.out.println("How long do you want the randomly generated list to be? (Enter an integer greater than 0)");
            lenOfList= Integer.parseInt(scan.nextLine()); 
        }
        while(lenOfList<0);
        // ask for number they want to find in the list
        System.out.println("What is the integer you want to find in the list?");
        int number = Integer.parseInt(scan.nextLine());
        
        System.out.println("Index position of the number: "+binarySearch(number,createList(lenOfList)));
   
    }
    // finds the item using binary search
    public static int binarySearch(int item,ArrayList<Integer> sortedList){
        // impossible for list in item to be less than zero or greater than or= to the size of the list so return -1
        if(item<0 || item>=sortedList.size()){
            return(-1);
        }
        // declare variables, high is the last item in the list, low is the first
        int high=sortedList.get(sortedList.size()-1),low=sortedList.get(0),mid;
        
        while(high>=low){
            // mid is the middle index
            mid=(high+low)/2;
            // if the middle index's number is equal to the item's number, return the middle index
            if(sortedList.get(mid)==item){
                return(mid);
            }
            // if the middle index's number is less than the item, change low to mid+1 (first half of list will now ignored)
            if(sortedList.get(mid)<item){
                low=mid+1;
            }
            // if the middle index's number is more than the item, change high to mid-1 (second half of list will now ignored)
            if(sortedList.get(mid)>item){
                high=mid-1;
            }
        }
        // item is not in the list
        return(-1);
    }
    // makes the randomly list of sorted numbers between 0 and the user's length-1
    public static ArrayList<Integer> createList(int length){
        // make objects
        ArrayList<Integer> sortedList=new ArrayList<>();
        Random RandomNumber = new Random();
        // fill the list up with random numbers between 0 and length-1
        for(int i=0;i<length;i++){
            sortedList.add(RandomNumber.nextInt(length)); // number between 0 and length-1
        }
        // sort the list and return it
        Collections.sort(sortedList);
        System.out.println("Randomly Generated List: "+sortedList);
        return(sortedList);
    }
    
}


/*
long start = System.nanoTime();
long stop = System.nanoTime();
System.out.println("Time taken in nanoseconds: "+(stop-start)); 
*/