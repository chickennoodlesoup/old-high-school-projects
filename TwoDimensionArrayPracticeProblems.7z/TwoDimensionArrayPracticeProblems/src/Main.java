public class Main {
    public static void main(String args[]) {
        // 5x5 array filled with random numbers 
        int[][] array=randArray(5);
        
        // sum of all the numbers in the array
        System.out.println(sumArray(array));
        
        //print array before flipping
        printArray(array); 
        System.out.println();
        
        array=flipArray(array);
        //print flipped array
        printArray(array);
    }
    
    public static int[][] flipArray(int[][] array){       
        int[][] flippedArray=new int[array.length][array[0].length];
        int z;
        for(int y=0;y<array.length;++y){
            z=0;
            // for each row, flippedArray starts from the left side and array starts from the right side
            for(int x=array[y].length-1;x>=0;--x){
                // make to current position of flippedArray equal to the current position of array
                flippedArray[y][z]=array[y][x];
                ++z;
            }
        }
        // return the flippedArray
        return(flippedArray);
        
    }
    
    public static int sumArray(int[][] array){
        int sum=0;
        // go through the array
        for(int y=0;y<array.length;++y){
            for(int x=0;x<array[y].length;++x){
                // add the current value to sum
                sum+=array[y][x];
            }
        }
        return(sum);
        
    }
    // method that fills array with random numbers between 0 and 99
    public static int[][] randArray(int size){
        int[][] randArray=new int[size][size];
        for(int y=0;y<size;++y){
            for(int x=0;x<size;++x){
                randArray[y][x]=(int)(Math.random()*100);
            }
        }
        return(randArray);
        
    }
    
    // method that prints the array  
    public static void printArray(int[][] array){
        for(int y=0;y<array.length;++y){
            for(int x=0;x<array[y].length;++x){
                System.out.print(array[y][x]+" ");
            }
            System.out.println();
        }
        
    }
}
