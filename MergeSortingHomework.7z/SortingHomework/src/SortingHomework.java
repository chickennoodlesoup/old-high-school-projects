import java.util.ArrayList;
import java.util.Random;
public class SortingHomework {
    public static void main(String[] args) {
        
    // make some arrays filled with random numbers
        Random ron = new Random();
        ArrayList<Integer> nums1=new ArrayList<>();
        ArrayList<Integer> nums2=new ArrayList<>();
        ArrayList<Integer> nums3=new ArrayList<>();
        
        for(int i=10;i>0;--i){
            nums1.add(ron.nextInt(10000));
            nums2.add(ron.nextInt(10000));
            nums3.add(ron.nextInt(10000));
        }
        
        nums1=bubbleSort(nums1);
        nums2=bubbleSort(nums2);
        
        System.out.println(nums1+"\n");
        System.out.println(nums2+"\n");
        
        System.out.println(mergeTwoSortedArrays(nums1,nums2)+"\n");
        
        System.out.println(nums3);
        System.out.println(mergeSort(nums3));
    }
    public static ArrayList<Integer> bubbleSort(ArrayList<Integer> nums){
        int numLength=nums.size();
        for(int i=0;i<numLength;++i){
            boolean isSorted=true;
            for(int j=1;j<numLength;++j){
                int temp=nums.get(j-1);
                int temp2=nums.get(j);
                if(temp<temp2){
                    nums.set(j-1,temp2);
                    nums.set(j,temp);
                    isSorted=false;
                }
            }
            // will stop checking if there was not a single swap in the last check
            if(isSorted){
                break;
            }
        }
        return(nums);
    }
     public static ArrayList<Integer> mergeTwoSortedArrays(ArrayList<Integer> nums1,ArrayList<Integer> nums2){
        int totalNumsLen=nums1.size()+nums2.size();
        int numLen1=nums1.size();
        int numLen2=nums2.size();   
        ArrayList<Integer> mergedArray= new ArrayList<>();
        int i=0;
        int j=0;
        
        // go through the arrays check if current number in num1 is <= current number in num2
        // add the greater one to the list
        for(int count=0;count<totalNumsLen;count++){
            if(i<numLen1&&j<numLen2){
            int a=nums1.get(i);
            int b=nums2.get(j);
            if(a<=b){
                mergedArray.add(nums2.get(j));
                    j++;
                    
                }
            else{
                mergedArray.add(nums1.get(i));
                    i++;     
                }
            }
            // break loop when i or j is more than their array lengths
            else{
                break;
            }
        }
        // if j or i is less than the array lengths of nums1 & nums2
        // then it means some numbers at the end of the one of the arrays were not added to the mergedArray 
        // (this is because the numbers were less than the last number in the other array)
        // these for loops adds them to the new array
        for(;i<numLen1;++i){
            mergedArray.add(nums1.get(i));
        }
        for(;j<numLen2;++j){
            mergedArray.add(nums2.get(j));
        } 
        return(mergedArray);
    }
     
    public static ArrayList<Integer> mergeSort(ArrayList<Integer> nums1){
        // base case array is length one so it cant be split further
        if(nums1.size()==1){
            return nums1;
        }
        ArrayList<Integer> nums2=new ArrayList<>();
        ArrayList<Integer> nums3=new ArrayList<>();
        
        int numLen = nums1.size();
        
        // splits current array in half
        for(int i=0;i<numLen;++i){
            if(i<=(numLen/2)-1){
                nums2.add(nums1.get(i));     
            }
            else{ 
                nums3.add(nums1.get(i));
            }  
        }
        /*
        mergeSort(nums2)& mergeSort(nums2)will eventually return an array of size one(base case)
        an array of size one is already sorted so the mergeTwoSortedArrays() function 
        can merge the two arrays together forming a sorted array of size two, 
        since it is the new array is sorted it can then be merged again using the mergeTwoSortedArrays() 
        it keeps repeating this until done
        */
        return mergeTwoSortedArrays(mergeSort(nums2),mergeSort(nums3));
                      
      }
}

