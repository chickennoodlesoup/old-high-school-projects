import javafx.animation.AnimationTimer;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;



public class Box extends Rectangle{
    boolean active;
    static int numScore=0;
    public Box(Stage window){
        //x,y,w,h
        super(700, 350, 50, 50);
        setFill(Color.BLUE);
        
                
    }
    public Box(Stage window,Pane pane, Box mainBox, Label score){
        //x,y,w,h
        
        super((int)(Math.random()*window.getWidth())-40,10,50,50);

        if((int)(Math.random()*2)==0){
            setFill(Color.BLUE);

        }
        else{
            setFill(Color.RED);

        }
        
        Box box=this;
        active=true;
       
        AnimationTimer timer = new AnimationTimer() {
        @Override
        public void handle(long now) {
                if (JavaFXProject.gameStarted==false){
                    removeBox(box,pane);
                }
                
                if(box.getBoundsInParent().intersects(mainBox.getBoundsInParent())){
                    if(box.getFill()==Color.BLUE && active){
                        mainBox.setHeight(mainBox.getHeight()+5);
                        mainBox.setWidth(mainBox.getWidth()+5);
                        numScore++;
                        if(Box.numScore>(Integer.parseInt(JavaFXProject.highScore.getText()))){
                        JavaFXProject.highScore.setText(""+Box.numScore);
                        JavaFXProject.saveHighScore();
                        }
                        if(numScore <10){
                            score.setText("0"+numScore);
                        }
                        else{
                            score.setText(""+numScore);
                            
                        }
                        
                        
                        
                    }
                    else{
                        JavaFXProject.resetGame(mainBox,score,numScore);
                        
                    }
                    switch(numScore){
                            case 0:
                                pane.setStyle("-fx-background-color:lightblue");
                                score.setStyle("-fx-text-fill:white");
                                break;
                            case 10:
                                pane.setStyle("-fx-background-color:brown");
                                score.setStyle("-fx-text-fill:white");
                                break;
                            case 20:
                                pane.setStyle("-fx-background-color:green");
                                break;
                            case 30:
                                pane.setStyle("-fx-background-color:purple");
                                break;
                            case 40:
                                pane.setStyle("-fx-background-color:orange");
                                break;
                            case 50:
                                pane.setStyle("-fx-background-color:yellow");
                                score.setStyle("-fx-text-fill:black");
                                break;
                            case 60:
                                pane.setStyle("-fx-background-color:pink");
                                score.setStyle("-fx-text-fill:white");
                                break;
                            case 70:
                                pane.setStyle("-fx-background-color:lightgreen");
                                break;
                            case 80:
                                pane.setStyle("-fx-background-color:magenta");
                                break;
                            case 90:
                                pane.setStyle("-fx-background-color:black");
                                break;
                            case 100:
                                pane.setStyle("-fx-background-color:white");
                                score.setStyle("-fx-text-fill:black");
                                break;
                        }
                    removeBox(box,pane);
                    
                    
                    
                }
               
                if(box.getY() < window.getHeight()-60){
                    
                    box.setY(box.getY()+5);

                    
                }
                else{
                   removeBox(box,pane);
                   
                   
                   
                }
                
                
                
        }
        };
        timer.start();
        
                
    }
    void removeBox(Box box,Pane pane){
        box.active=false;
        
        box.setX(7000);
        box.setY(7000);
                
        pane.getChildren().remove(box);
        
        
    }
   
}