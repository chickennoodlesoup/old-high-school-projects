import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Pane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class ConfirmBox {
    static boolean answer;
    public static boolean display(String title, String message){
        
        Stage window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle(title);
        window.setHeight(250);
        window.setWidth(400);

        window.initStyle(StageStyle.UNDECORATED);
        Button yes = new Button();
        yes.setText("Yes");

        yes.setOnAction(e->{
            answer=true;
            window.close();
        });
        
        Button no = new Button();
        no.setText("No");
        
        no.setOnAction(e->{
            answer=false;
            window.close();
        });
        
        yes.setTranslateX(125);
        yes.setTranslateY(120);
        
        no.setTranslateX(220);
        no.setTranslateY(120);
        
        Label label = new Label();
        label.setText(message);
        label.getStyleClass().add("instructions");
        label.setTranslateY(50);
        label.setTranslateX(70);
        
        Label keys = new Label();
        keys.setText("<ENTER>\t\t\t     <ESC>");
        keys.getStyleClass().add("instructions");
        keys.setStyle("-fx-font-size:10px");
        keys.setTranslateY(165);
        keys.setTranslateX(133);
        
        Pane layout=new Pane();
        

        layout.getChildren().addAll(label,keys,yes,no);

        layout.getStyleClass().add("confirmbox");
    window.addEventFilter(KeyEvent.KEY_RELEASED, new EventHandler<KeyEvent>() {

 
    @Override
    public void handle(KeyEvent ke) {
        if (ke.getCode() == KeyCode.ESCAPE) {
            answer=false;
            window.close();
        }
        if (ke.getCode() == KeyCode.ENTER) {
            answer=true;
            window.close();
        }
    }
    });
        
        Scene scene = new Scene(layout);
        scene.getStylesheets().add("style.css");
        window.setScene(scene);
        window.showAndWait();
        
        return answer;
    }
}
