import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.animation.AnimationTimer;
import javafx.event.EventHandler;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyCodeCombination;
import javafx.scene.input.KeyCombination;
import javafx.scene.input.KeyEvent;
import javafx.stage.StageStyle;

public class JavaFXProject extends Application {
    Stage window;
    static Pane pane;
    static boolean leftKeyDown= false;
    static boolean rightKeyDown= false;
    int gravity=5;
    int count=0;
    static boolean gameStarted = false;
    Rectangle top=new Rectangle(7000,7000,2000,25);
    
    Rectangle bot=new Rectangle(7000,7000,2000,10);
    Rectangle left=new Rectangle(7000,7000,10,2000);
    Rectangle right=new Rectangle(7000,7000,10,2000);
    Menu options = new Menu("_Add Red Borders");
    static Label startInstructions = new Label();
    static Label instructions = new Label();
    static Label highScore = new Label("0");
    static Label morekeys = new Label();
    MenuBar menuBar = new MenuBar();
    

    public static void main(String[] args) {
        launch(args);
    }
    @Override
    public void start(Stage stage) throws Exception{
        
        window=stage;
        window.setTitle("Avoid The Red");
        window.setOnCloseRequest(e->{
            e.consume();
            closeProgram();
                });

        window.setMaximized(true);
        window.initStyle(StageStyle.UNDECORATED);
        instructions.setText("Use arrow keys to move. Avoid red things. Get blue things.");
        instructions.getStyleClass().add("instructions");
        instructions.setTranslateY(150);
        instructions.setTranslateX(475);
        
        
        startInstructions.setText("Press an arrow key to start.");
        startInstructions.getStyleClass().add("instructions");
        startInstructions.setTranslateY(600);
        startInstructions.setTranslateX(630);
        
        
        morekeys.setText("The keys T, B, R, L and ESC all do something.");
        morekeys.getStyleClass().add("instructions");
        morekeys.setTranslateY(700);
        morekeys.setTranslateX(540);
        
        Label score = new Label();
        score.setText("00");
        score.getStyleClass().add("score");
        score.setTranslateY(90);
        score.setTranslateX(510);
        
        
        highScore.getStyleClass().add("highscore");
        highScore.setTranslateY(720);
        highScore.setTranslateX(1320);
        
        Label highScoreLabel = new Label("Highscore");
        highScoreLabel.getStyleClass().add("instructions");
        highScoreLabel.setTranslateY(700);
        highScoreLabel.setTranslateX(1315);
        
        loadHighScore();
        
        
        
        
        Menu fileMenu = new Menu("_File");
        
        
        
        menuBar.getMenus().addAll(fileMenu,options);
        menuBar.prefWidthProperty().bind(window.widthProperty());
        
        MenuItem reset= new MenuItem("Reset Highscore");
        fileMenu.getItems().add(reset);
        reset.setOnAction(e ->{
            highScore.setText("0");
            saveHighScore();
        });
        MenuItem exit= new MenuItem("Exit");
        fileMenu.getItems().add(exit);
        exit.setOnAction(e -> closeProgram());
        
        pane= new Pane();
        Box box = new Box(window);
        
        
        pane.getChildren().addAll(instructions,startInstructions,morekeys,highScore,highScoreLabel,score,box,menuBar);
        
        borderStuff();

        
        
        Scene scene = new Scene(pane);
        scene.getStylesheets().add("style.css");
        stage.setScene(scene);
        stage.show();
        
        AnimationTimer timer = new AnimationTimer() {
        @Override
        public void handle(long now) {
            
            if(top.getBoundsInParent().intersects(box.getBoundsInParent())||
                    bot.getBoundsInParent().intersects(box.getBoundsInParent())||
                    left.getBoundsInParent().intersects(box.getBoundsInParent())||
                    right.getBoundsInParent().intersects(box.getBoundsInParent())){
                resetGame(box,score,Box.numScore);
                gravity=0;
            }
            if(gameStarted){
                
                box.setY(box.getY()+gravity);
            
            if (count>50){
                pane.getChildren().add(new Box(window,pane,box,score));

                count=0;
            }
            count++;
            if(box.getY() < window.getHeight()-box.getHeight()-5){

                gravity++;


            }
            else{
                gravity=0;
                box.setY(window.getHeight()-box.getHeight()-5);
            }
            }
            if(box.getY() < 25){
                box.setY(25);
                gravity=0;


            }
            if(rightKeyDown){
                box.setX(box.getX()+10);
                if(box.getX()>window.getWidth()-box.getWidth()-5){
                    box.setX(window.getWidth()-box.getWidth()-5);
                }
            }

            if(leftKeyDown){
                box.setX(box.getX()-10);
                if(box.getX()<5){
                    box.setX(5);
                }
            }
                
        }
        };
        timer.start();
        
window.addEventFilter(KeyEvent.KEY_PRESSED, new EventHandler<KeyEvent>() {
    @Override
    public void handle(KeyEvent ke) {
        
        
        if (ke.getCode() == KeyCode.LEFT) {
            gameStarted=true;
            pane.getChildren().removeAll(startInstructions,instructions,morekeys);
            leftKeyDown= true;
             
            
  
        }
        if (ke.getCode() == KeyCode.RIGHT) {
            gameStarted=true;
            pane.getChildren().removeAll(startInstructions,instructions,morekeys);
            rightKeyDown= true;
            
            

        }
        
        if (ke.getCode() == KeyCode.UP) {
            gameStarted=true;
            pane.getChildren().removeAll(startInstructions,instructions,morekeys);
            gravity=-20;
            

        }
        
    }
});
window.addEventFilter(KeyEvent.KEY_RELEASED, new EventHandler<KeyEvent>() {

    final KeyCombination keyComb = new KeyCodeCombination(KeyCode.Q, KeyCombination.CONTROL_ANY);
    @Override
    public void handle(KeyEvent ke) {

        if (ke.getCode() == KeyCode.LEFT) {
            leftKeyDown= false;

        }
        if (ke.getCode() == KeyCode.RIGHT) {
            rightKeyDown= false;

        }
        if (ke.getCode() == KeyCode.T) {
            if(top.getX()==7000){
                addBorder(top,0,0);
                menuBar.toFront();
            }else{
                removeBorder(top);
            }
            

        }
        if (ke.getCode() == KeyCode.B) {
            if(bot.getX()==7000){
                addBorder(bot,0,890);
            }else{
                removeBorder(bot);
            }

        }
        if (ke.getCode() == KeyCode.R) {
            if(right.getX()==7000){
                addBorder(right,1430,0);
            }else{
                removeBorder(right);
            }

        }
        if (ke.getCode() == KeyCode.L) {
            if(left.getX()==7000){
                addBorder(left,0,0);
            }else{
                removeBorder(left);
            }

        }

        if (keyComb.match(ke)||ke.getCode() == KeyCode.ESCAPE) {
            closeProgram();
        }
    
        
    }
});


    }
    
    
    private void closeProgram(){
        
        if(ConfirmBox.display("Confirm","Are you sure you want to exit?")){
            window.close();
        }
    }
    
    public static void resetGame(Box mainBox,Label score, int numScore){
        mainBox.setX(700);
        mainBox.setY(350);
        mainBox.setHeight(50);
        mainBox.setWidth(50);
        
        score.setText("00");
        gameStarted= false;
        rightKeyDown= false;
        leftKeyDown= false;
        pane.getChildren().addAll(startInstructions,instructions,morekeys);
        
        Box.numScore=0;
    }
    public void borderStuff(){
        top.setFill(Color.RED);
        bot.setFill(Color.RED);
        left.setFill(Color.RED);
        right.setFill(Color.RED);
        
        
        
        CheckMenuItem topBorderSwitch= new CheckMenuItem("Top Border");
        options.getItems().add(topBorderSwitch);
        topBorderSwitch.setOnAction(e->{
            if(topBorderSwitch.isSelected()){
                addBorder(top,0,0);
                menuBar.toFront();
            }else{
                removeBorder(top);
                
            }
        });
        CheckMenuItem botBorderSwitch= new CheckMenuItem("Bottom Border");
        options.getItems().add(botBorderSwitch);
        botBorderSwitch.setOnAction(e->{
            if(botBorderSwitch.isSelected()){
                addBorder(bot,0,890);
            }else{
                removeBorder(bot);
                
            }
        });
        CheckMenuItem leftBorderSwitch= new CheckMenuItem("Left Border");
        options.getItems().add(leftBorderSwitch);
        leftBorderSwitch.setOnAction(e->{
            if(leftBorderSwitch.isSelected()){
                addBorder(left,0,0);
            }else{
                removeBorder(left);
            }
        });
        CheckMenuItem rightBorderSwitch= new CheckMenuItem("Right Border");
        options.getItems().add(rightBorderSwitch);
        rightBorderSwitch.setOnAction(e->{
            if(rightBorderSwitch.isSelected()){
                addBorder(right,1430,0);
               
            }else{
                removeBorder(right);
                
            }
        });
    }
    
    static void loadHighScore(){
        String fullFileName=System.getProperty("user.dir")+"/highscore.txt";
        BufferedReader br=null;
        //get the file
        try{
            
            FileReader fr = new FileReader(fullFileName);
            br = new BufferedReader(fr);
        }
        catch(FileNotFoundException ex){
            System.out.println("Highscore file is missing?");
        }
        String line;



        try{
            while((line=br.readLine())!=null){
                highScore.setText(line.substring(0));
            }
        }

        catch(IOException e){
            System.out.println("Highscore file is missing?");
        }
    }
    
    static void saveHighScore(){
        String fullFileName=System.getProperty("user.dir")+"/highscore.txt";
        try{
            //get file
            FileWriter fw = new FileWriter(fullFileName,false);
            BufferedWriter br = new BufferedWriter(fw);
            // clears text
            br.write(highScore.getText());
            

            br.close();
        }
        //file not found
        catch(IOException ex){
            System.out.println("Something is wrong.");
        }
    }
    
    static void addBorder(Rectangle border,int x, int y){
        if(border.getX()==7000){
            pane.getChildren().add(border);
            border.setX(x);
            border.setY(y);
        }
        
    }
    
    static void removeBorder(Rectangle border){
        if(border.getX()!=7000){
            pane.getChildren().remove(border);
            border.setX(7000);
            border.setY(7000);
        }
    }
    
    
  
}    

    
    

