import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.FlowPane;
import javafx.stage.Stage;
import java.util.Random;

public class RockPaperScissors extends Application{
    Button rock,paper,scissors;
    int numWin=0, numLoss=0, numTie=0;
    public static void main(String[] args) {     
        launch(args);
    }
    @Override
    public void start(Stage stage) throws Exception{
        // title of window
        stage.setTitle("Rock Paper Scissors");
        // buttons
        rock = new Button();
        rock.setText("Rock");
        paper = new Button();
        paper.setText("Paper");
        scissors = new Button();
        scissors.setText("Scissors");
        // labels
        Label label = new Label();
        label.setText("Choose something");
        Label text = new Label();
        text.setText("\t\t\t\t\t\t\t");
        Label count = new Label();
        count.setText("Win/Loss/Tie: 0/0/0");

        Random rand = new Random();

        // rock button pressed
        rock.setOnAction(e -> {
            int  n = rand.nextInt(3);
            label.setText("You chose rock."); 
            switch(n){
                case 0: text.setText("The computer chose rock, it's a tie.");
                        numTie++;
                        break;
                case 1: text.setText("The computer chose paper, you lose.");
                        numLoss++;
                        break;
                case 2: text.setText("The computer chose scissors, you win.");
                        numWin++;
                        break;
            }
            count.setText("Win/Loss/Tie: "+numWin+"/"+numLoss+"/"+numTie);
        });
        
        // paper button pressed
        paper.setOnAction(e -> {
            int  n = rand.nextInt(3);
            label.setText("You chose paper.");
            switch(n){
                case 0: text.setText("The computer chose rock, you win.");
                        numWin++;
                        break;
                case 1: text.setText("The computer chose paper, it's a tie.");
                        numTie++;
                        break;
                case 2: text.setText("The computer chose scissors, you lose.");
                        numLoss++;
                        break;
            }
            count.setText("Win/Loss/Tie: "+numWin+"/"+numLoss+"/"+numTie);
        });
        
        // scissors button pressed
        scissors.setOnAction(e -> {
            int  n = rand.nextInt(3);
            label.setText("You chose scissors.");
            switch(n){
                case 0: text.setText("The computer chose rock, you lose.");
                        numLoss++;
                        break;
                case 1: text.setText("The computer chose paper, you win.");
                        numWin++;
                        break;
                case 2: text.setText("The computer chose scissors, it's a tie.");
                        numTie++;
                        break;
            }
            count.setText("Win/Loss/Tie: "+numWin+"/"+numLoss+"/"+numTie);
        });
        FlowPane layout = new FlowPane(50,50);
        layout.getChildren().addAll(rock,paper,scissors, label,text,count);
        Scene scene = new Scene(layout,400,400);
        stage.setScene(scene);
        stage.show();
    }
    
}
