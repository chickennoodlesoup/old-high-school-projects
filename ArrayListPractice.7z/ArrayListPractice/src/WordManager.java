import java.util.ArrayList;

public class WordManager {
    
    ArrayList<String> wordbank;
    ArrayList<String> usedwords;
    
    public WordManager() {
        wordbank = new ArrayList<String>();
        usedwords = new ArrayList<String>();
        //fill with some words
        wordbank.add("apple"); wordbank.add("ball"); wordbank.add("car"); wordbank.add("dragon");
        wordbank.add("elephant"); wordbank.add("fire"); wordbank.add("gorilla");
    }
    
    
    //picks and returns a random word from the wordbank.  this word should not be returned again
    //until all other words in the wordbank have been used.  if the wordbank is currently empty, calls
    //recycle to recycle the used words.
    public String getWord() {
        //your code
        return("something");
    }
    
    
    //puts all used words back into the wordbank and then clears the usedwords list
    public void recycle() {
    }
}
