
public class Racer {
    
    public int racerId;
    public double raceTime;
    
    public Racer() {
        //for testing, lets give the Racer an id and a raceTime between 10 and 25
        racerId = (int)(Math.random()*9999) + 10000;
        raceTime = Math.random()*15 + 10;
    }
    
    public int getId() {
        return(racerId);
    }
    
    public double getRaceTime() {
        return(raceTime);
    }
}
