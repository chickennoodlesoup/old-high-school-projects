
public class WordManagerTester {
    
        public static void main(String[] args) {
            //tests out the WordManager class to make sure it is working properly
            WordManager WM = new WordManager();
            
            //test 01 - single word test, no recycle will be used... 
            String s = WM.getWord();
            System.out.println(s);
            
            //test 02 - lots of words! recycling better be working...
            for (int k=0; k<30; k++) {
                s = WM.getWord();
                System.out.println("Test " + k + " --> " + s);
            }
            
            //that's it!  check to see that all the words are used before they start repeating
        }
}
