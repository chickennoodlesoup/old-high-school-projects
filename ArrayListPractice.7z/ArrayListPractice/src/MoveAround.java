import java.util.ArrayList;

//note: an ArrayList cannot store primitive data types, so we can't make an ArrayList of <int>.
//You have to make an ArrayList of Integer instead, which is a 'wrapper' class.  The Integer class
//wraps up an integer value...

public class MoveAround {
    
    public static void main(String[] args) {
        ArrayList<Integer> nums = new ArrayList<Integer>();
        nums.add(1);
        nums.add(2);
        nums.add(3);
        nums.add(4);
        nums.add(5);
        //your code...
        // remove the first number from nums and add it to the end of nums
        nums.add(nums.remove(0));
        System.out.println(nums);
        
        ArrayList<Integer> nums2 = new ArrayList<Integer>();
        nums2.add(1);
        nums2.add(2);
        nums2.add(3);
        nums2.add(4);
        nums2.add(5);
        //your code...
        // removes the last number from nums2 and adds it to the first index of nums2
        nums2.add(0,nums2.remove(nums2.size()-1));
        System.out.println(nums2);
    }
}


