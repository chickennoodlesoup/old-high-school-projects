import java.util.ArrayList;


public class FriendsSelected {
    
        public static void main(String[] args) {
            //your code
            // create string ArrayList friends
            ArrayList<String> friends = new ArrayList<String>();
            // add some Strings which are supposed to be names to friends
            friends.add("A");
            friends.add("B");
            friends.add("C");
            friends.add("D");
            friends.add("E");
            friends.add("F");
            // create string ArrayList selected
            ArrayList<String> selected = new ArrayList<String>();
            // get a random number between 0 and 5 and remove that index number's letter from friends
            // add the removed letter to selected
            selected.add(friends.remove((int)(Math.random()*6)));
            // print out the two lists
            System.out.println(friends +"\n"+selected);
        }
}
