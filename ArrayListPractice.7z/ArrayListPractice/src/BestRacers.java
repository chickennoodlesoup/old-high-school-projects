import java.util.ArrayList;


public class BestRacers {
        
    public static void main(String[] args) {
            
          ArrayList<Racer> allRacers = new ArrayList<Racer>();
          //lets fill this up with some racers (remember that they get random statistics when constructed)
          for(int k=0; k<25; k++) {
              Racer R = new Racer();
              allRacers.add(R);
          }
          //lets show all the racers
          for(int k=0; k<allRacers.size(); k++) {
              Racer temp = allRacers.get(k);
              System.out.println("Racerid " + temp.getId() + " had time of " + temp.getRaceTime() );
          }
          
          ArrayList<Racer> fastRacers = new ArrayList<Racer>();
          
          //your code to add all fast racers to the fastRacers list
          // goes through all the racers and if the racer's time is less than or equal to 13 seconds,
          // add that racer to the fastRacers list then print it's id and time
          for(Racer r:allRacers){
              if(r.getRaceTime()<=13){
                  fastRacers.add(r);
                  System.out.print("Racer Id: "+r.getId()+" Time: "+r.getRaceTime()+"\n");
              }
          }
          
          //your code to determine the id of the fastest racer in the fastRacer list
          //hint: very related to the 'find minimum value' code you've done/seen before
          // set the current fastestRacer to the first person in the fastRacers list
          // and remove that racer from the list
          Racer fastestRacer = fastRacers.remove(0);
          // go through the list of racers and if the racer is faster than the previous fastestRacer 
          // then replace it
          for(Racer r:fastRacers){
              if(r.getRaceTime() < fastestRacer.getRaceTime()){
                  fastestRacer = r;
              }
          }
          // print out the fastestRacer's Id
          System.out.println("Fastest Racer's Id: " + fastestRacer.getId());
            
    }
}
