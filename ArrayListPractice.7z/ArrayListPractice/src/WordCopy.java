
import java.util.ArrayList;


public class WordCopy {
    
    public static void main(String[] args) {
        ArrayList<String> words = new ArrayList<String>();
        words.add("apple");
        words.add("ball");
        words.add("car");
        //etc...
        // create ArrayList of type String
        ArrayList<String> copies = new ArrayList<String>();
        // copy every item in words to copies
        for(String s:words){
            copies.add(s);
        }
        // print out new list
        System.out.println(copies);
        
    }
}
