import java.util.ArrayList;
public class Person {
    protected int personId;
    protected final ArrayList<Course> COURSES=new ArrayList<>();
    private final String FIRSTNAME,LASTNAME;
    
    // constructor takes in two Strings
    protected Person(String firstName, String lastName){
        // sets those two Strings to FIRSTNAME and LASTNAME
        FIRSTNAME=firstName;
        LASTNAME=lastName;
    }
    
    //"Method called speak that runs when object printed"
    // toString runs when Object is printed and it then calls speak()       
    @Override
    public String toString(){
        return(speak());
    }
    private String speak(){
        return("Speaking...");
    }
    
    // print full name of Object
    public void printName(){
        System.out.println(this.FIRSTNAME+" "+this.LASTNAME);
    }
   
    
}
