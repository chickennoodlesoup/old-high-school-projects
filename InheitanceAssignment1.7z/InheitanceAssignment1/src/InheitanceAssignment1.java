public class InheitanceAssignment1 {
    public static void main(String[] args) {
        // create course Math
        Course c= new Course("Math");
        
        // create teachers
        Teacher t= new Teacher("Ken","M");
        Teacher t2= new Teacher("A","B");
        
        //TESTING:
        
        // add two Math courses to t and delete one
        t.addCourse(c);
        t.addCourse(c);
        t.delCourse(c);
        
        // print array of courses
        t.printCourses();
        // print full name
        t.printName();
        // "Method called speak that runs when object printed"
        System.out.println(t);
        // print Ids
        System.out.println(t.getId());
        System.out.println(t2.getId());
        
        // create student
        Student s= new Student("Joe","S");
        // add one course Math, delete Math (zero courses now)
        s.addCourse(c);
        s.delCourse(c);
        
        // print courses (none)
        s.printCourses();
        // print full name
        s.printName();
        // "Method called speak that runs when object printed"
        System.out.println(s);
        // print Id
        System.out.println(s.getId());
        
    }
    
}
