public class Teacher extends Person{
    // variables
    private static int currentEmployeeId=0;

    // constructor takes in two Strings
    Teacher(String firstName, String lastName){
        // call super class with those two Strings as arguments
        super(firstName, lastName);
        // set the Id and add one to it 
        this.personId=currentEmployeeId;
        ++currentEmployeeId;
    }
    
    // method that takes a course and adds it to the ArrayList COURSES
    public void addCourse(Course course){
        this.COURSES.add(course);
    }
    
    // method that takes a course and removes it to the ArrayList COURSES
    // does nothing if the course is not in the ArrayList
    public void delCourse(Course course){
        this.COURSES.remove(course);
    }
    
    // method that prints all the COURSES in the COURSES ArrayList
    public void printCourses(){
        System.out.println(COURSES);
    }
    
    // method that returns the teacher's Id
    public int getId(){
        return(this.personId);
    }
}
