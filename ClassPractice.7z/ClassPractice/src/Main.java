public class Main {
    public static void main(String[] args){
        // Create student
        Student Joe = new Student("Joe");
        // Create Courses Math
        Courses Math = new Courses ("Math",50);
        // Add Courses Math to Joe's array of courses
        Joe.addCourse(Math);
        // Create Courses Science and Add it to Joe's array of courses
        Joe.addCourse(new Courses("Science",75));
        //Print out Joe's student id and name
        System.out.println(Joe);
        // print out Joe's average grade
        System.out.println("Average Grade:" + Joe.findAverage());
        // print out Joe's courses
        Joe.printCourses();
    }
}
