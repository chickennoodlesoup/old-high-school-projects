public class Student {
    // delcare variables
    private String studentName;
    private static int id;
    private Courses[] courses = new Courses[0];
    private int studentId;
    
    // constructor takes student's name
    public Student(String name){
        // asign name to Student name and id to studentId, increase id by 1
        studentName = name;
        studentId = id;
        id++;
    }
    // method that takes in a course
    public void addCourse(Courses course){ 
        int arrayLength = courses.length;
         // make tempArray 1 index longer than courses
        Courses[] tempArray = new Courses[arrayLength+1];
        // copy the array courses to tempArray
        for(int i =0; i<arrayLength;i++){
            tempArray[i] = courses[i];
        }
        // add the inputted course to tempArray
        tempArray[arrayLength] = course;
        // replace courses with tempArrau
        courses = tempArray;
    }
    // method that finds the average of all courses
    public double findAverage(){
        double averageGrade =0;
        // add all the grades to averageGrade
        for(Courses i: courses){
            averageGrade += i.getStudentGrade();
        }
        // divide averageGrade by the number of courses to get the average grade and return it 
        return(averageGrade/courses.length);
    }
    // method that returns the student id and name, get called when you try to print a Student object
    public String toString(){
        return("Student:\nStudent ID: " + studentId + "\nName: " + studentName);
    }
    // method that prints all the students courses
    public void printCourses(){
        System.out.println("Courses: ");
        // print out every index
        // each index is a Courses object
        // when it prints a Courses object it uses the Courses' toString() method 
        // and prints the subject name
        for(Courses t: courses){
            System.out.println(t);
        }
    }
    
}
