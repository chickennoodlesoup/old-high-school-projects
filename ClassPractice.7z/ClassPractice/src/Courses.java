public class Courses {
    // declare variables
    private String subjectName;
    private double studentGrade;
    
    // constructor that takes in a subjectName and studentGrade
    // and assigns it to the appropiate variable
    public Courses(String subjectName,double studentGrade){
        this.subjectName = subjectName;
        this.studentGrade = studentGrade;
    }
    // returns studentGrade
    public double getStudentGrade(){
        return(studentGrade);
    }
    // method that returns the subjectName of a course, get called when you try to print a Courses object
    public String toString(){
        return("Subject: " + subjectName);
    }
}
