public class Friend {
    // declare variables
    private final String name,password,birthdate;
    private final int age;
    // constructor that takes in 4 strings
    public Friend(String name,String age,String birthdate,String password){
        // set current Friend's attributes to the 4 strings
        this.name = name;
        this.age=Integer.parseInt(age);
        this.birthdate=birthdate;
        this.password=password;
    }
    // methods that return the Friend's attributes
    public String getName(){
        return(this.name);
    }
    public int getAge(){
        return(this.age);
    }
    public String getBirthdate(){
        return(this.birthdate);
    }
    public String getPassword(){
        return(this.password);
    }
    
    // when the Friend is printed, print its name instead
    @Override
    public String toString(){
        return(this.name);
    }
    
}
