public class Checker {
    public static void checkAge(int age) throws AgeException{
        // cant be younger than 5
        if(age<5){
            throw new AgeException(age);
        }
        
    }
    public static void checkName(String name) throws NameException{
        boolean properName=true;
        int numNotLetters=0;
        // the length of the full name has to be 3 characters or longer 
        // so that there is a firstname and lastname with a space separating them   
        if(name.length()>=3){
        for(int i=0;i<name.length();++i){
            // make sure only one character is not a letter
            // that character must be the space that is between the first name and last name
            if(!Character.isLetter(name.substring(i,i+1).charAt(0))){
                ++numNotLetters;
                if(numNotLetters>1){
                    properName=false;
                    break;
                }
                if(!name.substring(i,i+1).equals(" ")){
                    properName=false;  
                    break;
                }
            }
            
        }
        }
        else{
            properName=false;
        }
        
        if(properName==false){
            throw new NameException(name);
        }
        
    }
    
    
    public static void checkBirthdate(String birthdate) throws BirthdateException{
        
        boolean properFormat=true; 
        // the format MM/DD/YYYY is 10 characters long, minus 1 is 9
        int stringLen=birthdate.length()-1;
        if(stringLen==9){
        for(int i=0;i<stringLen;++i){
            // checks if positon 0,1,3,4,5-8 are integers
            if(i==0||i==1||i==3||i==4||i>5){
                if(Character.isDigit(birthdate.substring(i,i+1).charAt(0))==false){
                    properFormat=false;
                    break;
                }
            }
            // checks if position 2,5 are "/" 
            else if(!birthdate.substring(i,i+1).equals("/")){
                properFormat=false;
                break;
            }
        }
        // checks if last character is an integer
        if(Character.isDigit(birthdate.substring(9).charAt(0))==false){
            properFormat=false;
        }
        }
        else{
            properFormat=false;
        }
        if(properFormat==false){
            throw new BirthdateException(birthdate);
        }

        
    }
}
