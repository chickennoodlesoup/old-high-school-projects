public class BirthdateException extends Throwable{
    String birthdate;
    
    BirthdateException(String birthdate){
        this.birthdate=birthdate;
    }
    
    @Override
    public String toString(){
        return(birthdate+" is not valid birthdate. Use this format MM/DD/YYYY.");
    }
}
