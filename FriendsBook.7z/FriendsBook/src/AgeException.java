public class AgeException extends Throwable{
    int age;
    AgeException(int age){
        this.age=age;
    }
    
    @Override
    public String toString(){
        if (age <0){
            return(age+" is not valid age. You cannot have a negative age.");
        }
        return(age+" is not valid age. You must be 5 or older to use this.");
    }
}
