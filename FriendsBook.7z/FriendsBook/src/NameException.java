public class NameException extends Throwable{
    String name;
    
    NameException(String name){
        this.name=name;
    }
    
    @Override
    public String toString(){
        return(name+" is not valid name. Enter a first and last name separated by a space.");
    }
}
