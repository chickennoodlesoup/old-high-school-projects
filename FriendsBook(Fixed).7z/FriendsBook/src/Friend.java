public class Friend {
    // declare variables
    private final String name,age,birthdate,fruit;
    // constructor that takes in 4 strings
    public Friend(String name,String age,String birthdate,String fruit){
        // set current Friend's attributes to the 4 strings
        this.name = name;
        this.age=age;
        this.birthdate=birthdate;
        this.fruit=fruit;
    }
    // methods that return the Friend's attributes
    public String getName(){
        return(this.name);
    }
    public String getAge(){
        return(this.age);
    }
    public String getBirthdate(){
        return(this.birthdate);
    }
    public String getFruit(){
        return(this.fruit);
    }
}
