import java.util.Arrays;
public class MainChangeArray {
    public static void main(String[] args){
        // the array that is going to be modified, this array can be changed 
        String[] names = {"Name1","Name2","Name3","Name4"};
        // create a instance of ChangeArray
        ChangeArray arrayModifier = new ChangeArray();
        // create a new array with the last String in names deleted (Problem 1)
        String[] arrayWithLastStringDel = arrayModifier.delLastString(names);
        System.out.println(Arrays.toString(arrayWithLastStringDel));
        // create a new array with a string inserted at the preferred index, (Problem 2)
        // the "newName" (string you want added) and 2(index of where you want string to be added)can be changed
        String[] arrayWithInsertedString = arrayModifier.insertString(names,"newName",2);
        System.out.println(Arrays.toString(arrayWithInsertedString));
        // create a new array with one of the strings in names deleted based on index (Problem 3)
        // the 2(index you want deleted) can be modified
        String[] arrayWithDeletedString = arrayModifier.delString(names, 2);
        System.out.println(Arrays.toString(arrayWithDeletedString));
        // create a new array with one of the strings in names deleted based on string (Problem 4)
        // the "Name1"(string you want deleted) can be modified as long as its in the array
        String[] arrayWithDeletedStringChosenByName = arrayModifier.delStringChosenByName(names, "Name1");
        System.out.println(Arrays.toString(arrayWithDeletedStringChosenByName));
    }
    
}
