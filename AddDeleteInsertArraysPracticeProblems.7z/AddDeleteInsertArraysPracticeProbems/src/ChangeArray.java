public class ChangeArray {
    // Problem 1
    // method that returns string array, takes in string array
    public String[] delLastString(String[] inputArray){
        // lengthOfArray is how long the given array is
        int lengthOfArray = inputArray.length;
        // create new array that is one index shorter
        String[] tempArray = new String[lengthOfArray - 1];
        // keep copying given array to tempArray but stop right before the last index
        for(int i = 0; i < lengthOfArray-1;i++){
            tempArray[i] = inputArray[i];
        }
        // return the new array
        return (tempArray);
    }
    // Problem 2
    // method that returns string array, takes in string array, a string, and a integer
    public String[] insertString(String[] inputArray, String inputString, int inputIndex){
        // lengthOfArray is how long the given array is
        int lengthOfArray = inputArray.length;
        //create new array that is the same length as given array
        String[] tempArray = new String[lengthOfArray];
        // keep copying given array to tempArray 
        // but stop if the index equals to inputIndex (index user wants changed)
        // set that index to the inputted string instead
        for(int i = 0; i < lengthOfArray;i++){
            if(i == inputIndex){
                tempArray[i] = inputString;
                continue;
            }
            tempArray[i] = inputArray[i];  
        }
        // return the new array
        return tempArray;
    }
    // Problem 3
    // method that returns string array, takes in string array and a integer
    public String[] delString(String[] inputArray, int inputIndex){
        // lengthOfArray is how long the given array is
        int lengthOfArray = inputArray.length;
        // create new array that is one index shorter than given array
        String[] tempArray = new String[lengthOfArray - 1];
        // keep copying given array to tempArray 
        // but stop if the index equals to inputIndex (index user wants deleted)
        // and go to the next index on inputted array but stay on same index on tempArray
        for(int i = 0, a = 0; i < lengthOfArray-1;i++, a++){
            if(i == inputIndex){
                a = i + 1;
            }
            tempArray[i] = inputArray[a];
        }
        // return new array
        return tempArray;    
    }
    // Problem 4
    // method that returns string array, takes in string array and a string
    public String[] delStringChosenByName(String[] inputArray, String inputString){
        // lengthOfArray is how long the given array is
        int lengthOfArray = inputArray.length;
        // create new array that is one index shorter than given array
        String[] tempArray = new String[lengthOfArray - 1];
        // create a counter
        int counter = 0;
        // type of for loops that loops through
        for(String i:inputArray){
            if(i.equals(inputString)){
                continue;
            }
            tempArray[counter] = i;
            counter++;
        }
        return tempArray;
    }
}
