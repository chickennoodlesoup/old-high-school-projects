public class QueueAndStack {
    // declare variables
    private int lengthOfArray;
    private String[] userArray;
    private String userString;
    
    public QueueAndStack(){
        // keep asking user for the length of their array until its length is greater than 0
        do{
            lengthOfArray = UserInput.getInteger("What is the length of your current Stack or Queue?");
        }
        while(lengthOfArray <= 0);
        // make length of array the length of user's array
        userArray = new String[lengthOfArray];
        // make user enter each array item
        for(int i=0;i<lengthOfArray;i++){
            userArray[i] = UserInput.getString("What is the "+ i+"th item in your list?");
        }
         // ask user for item they want inserted
        userString = UserInput.getString("What do you want added to the Stack or Queue?");
    }
    public String[] getUserArray(){
        return(userArray);
    }
    public String getUserString(){
        return(userString);
    }

    // method that returns string array, takes in string array and string
    public String[] addQueue(String[] inputArray, String inputString){
        // arrayLength is how long the given array is
        int arrayLength = inputArray.length;
        // create new array whose length is equal to arrayLength +1
        String[] tempArray = new String[arrayLength+1];
        // copy array
        for(int i =0; i<arrayLength;i++){
            tempArray[i] = inputArray[i];
        }
        // make the last item in tempArray equal to the inputted string
        tempArray[arrayLength] = inputString;
        // return the new array
        return tempArray;
       
    }
    
    // method that returns string array, takes in string array
    public String[] delQueue(String[] inputArray){
        // arrayLength is the given array's length - 1
        int arrayLength = inputArray.length-1;
        //create new array whose length is equal to arrayLength
        String[] tempArray = new String[arrayLength];
        // copy array but skip the first item in inputArray
        for(int i =0; i<arrayLength;i++){
            tempArray[i] = inputArray[i+1];
        }
        // return the new array
        return tempArray;
    }
    
    // method that returns string array, takes in string array and string
    public String[] addStack(String[] inputArray, String inputString){
        // arrayLength is how long the given array is
        int arrayLength = inputArray.length;
        //create new array whose length is equal to arrayLength+1
        String[] tempArray = new String[arrayLength+1];
        // copy array
        for(int i =0; i<arrayLength;i++){
            tempArray[i] = inputArray[i];
        }
        // make the last item in tempArray equal to the inputted string
        tempArray[arrayLength] = inputString;
        // return the new array
        return tempArray;
    }
    
    // method that returns string array, takes in string array
    public String[] delStack(String[] inputArray){
        // arrayLength is the given array's length - 1
        int arrayLength = inputArray.length-1;
        // create new array whose length is equal to arrayLength
        String[] tempArray = new String[arrayLength];
        // copy array except for the last item1
        for(int i =0; i<arrayLength;i++){
            tempArray[i] = inputArray[i];
        }
        // return the new array
        return tempArray;
    }
    /* integers > converted user input to string instead
    public int[] addQueue(int[] inputArray, int inputInt){
        int arrayLength = inputArray.length;
        int[] tempArray = new int[arrayLength+1];
        for(int i =0; i<arrayLength;i++){
            tempArray[i] = inputArray[i];
        }
        tempArray[arrayLength] = inputInt;
        return tempArray;
       
    }
    public int[] delQueue(int[] inputArray){
        int arrayLength = inputArray.length-1;
        int[] tempArray = new int[arrayLength];
        for(int i =0; i<arrayLength;i++){
            tempArray[i] = inputArray[i+1];
        }
        return tempArray;
    }
    public int[] addStack(int[] inputArray, int inputInt){
        int arrayLength = inputArray.length;
        int[] tempArray = new int[arrayLength+1];
        for(int i =0; i<arrayLength;i++){
            tempArray[i] = inputArray[i];
        }
        tempArray[arrayLength] = inputInt;
        return tempArray;
    }
    
    public int[] delStack(int[] inputArray){
        int arrayLength = inputArray.length-1;
        int[] tempArray = new int[arrayLength];
        for(int i =0; i<arrayLength;i++){
            tempArray[i] = inputArray[i];
        }
        return tempArray;
    }
    */ 
}
