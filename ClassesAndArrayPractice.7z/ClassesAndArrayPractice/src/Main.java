import java.util.Arrays;
public class Main {
        public static void main(String[] args){
            QueueAndStack QueueOrStack = new QueueAndStack();
            
            // Add Queue
            System.out.println("Add Queue: " + Arrays.toString(
                    QueueOrStack.addQueue(QueueOrStack.getUserArray(), QueueOrStack.getUserString())));
            
            // Delete Queue
            System.out.println("Delete Queue: " + Arrays.toString(
                    QueueOrStack.delQueue(QueueOrStack.getUserArray())));
            
            // Add Queue
            System.out.println("Add Stack: " + Arrays.toString(
                    QueueOrStack.addStack(QueueOrStack.getUserArray(), QueueOrStack.getUserString())));
            
            // Delete Queue
            System.out.println("Delete Stack: " + Arrays.toString(
                    QueueOrStack.delStack(QueueOrStack.getUserArray())));
        }
}
